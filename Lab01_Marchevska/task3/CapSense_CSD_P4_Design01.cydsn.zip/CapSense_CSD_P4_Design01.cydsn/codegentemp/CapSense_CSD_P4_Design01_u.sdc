# Component constraints for C:\Users\Daniella\PSoC Creator\CSN_UzhNU\CapSense_CSD_P4_Design01.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\Daniella\PSoC Creator\CSN_UzhNU\CapSense_CSD_P4_Design01.cydsn\CapSense_CSD_P4_Design01.cyprj
# Date: Thu, 26 Mar 2026 20:27:44 GMT
