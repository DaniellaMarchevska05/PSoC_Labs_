# Component constraints for C:\Users\Daniella\PSoC Creator\CSN_UzhNU\LW01.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\Daniella\PSoC Creator\CSN_UzhNU\LW01.cydsn\LW01.cyprj
# Date: Thu, 26 Mar 2026 20:14:43 GMT
