# Component constraints for C:\Users\Daniella\PSoC Creator\CSN_UzhNU\Design01.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\Daniella\PSoC Creator\CSN_UzhNU\Design01.cydsn\Design01.cyprj
# Date: Thu, 26 Mar 2026 20:14:32 GMT
